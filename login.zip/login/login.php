<?php session_start(); ?>

<?php
if (isset($_GET["error"])) {
    if ($_GET["error"] == "emptyinput") {
        echo "<p>Fill in all fields!</p>";
    } else if ($_GET["error"] == "invaliduid") {
        echo "<p>Choose a proper username</p>";
    } else if ($_GET["error"] == "invaliduemail") {
        echo "<p>Choose a proper email</p>"; // Fixed typo here
    } else if ($_GET["error"] == "usernametaken") {
        echo "<p>Passwords don't match!</p>";
    } else if ($_GET["error"] == "stmtfailed") {
        echo "<p>Something went wrong! Try again!</p>";
    } else if ($_GET["error"] == "usernametaken") {
        echo "<p>Try another username</p>";
    } else if ($_GET["error"] == "none") {
        echo "<p>Successfully Signed Up!</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Login Form</title>
      <meta name="viewport" content="width=device-width" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.2/css/bootstrap.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css'>
      <link rel="stylesheet" href="../style/css/login.css">
      
   </head>
   <body>
      <div class="wrapper">
         <div class="title">Login Form
         </div>
         <form action="../login/login-inc.php" method="POST"> <!-- Added method="POST" -->
            <div class="field">
               <input type="text" name="uid" required> <!-- Added name="uid" -->
               <label>Email Address</label>
            </div>
            <div class="field">
               <input type="password" name="pwd" required> <!-- Added name="pwd" -->
               <label>Password</label>
            </div>
            <div class="content">
               <div class="pass-link">
                  <a href="#">Forgot password?</a>
               </div>
            </div>
            <div class="field">
               <input type="submit" class="login" value="Login" name="login"> <!-- Added name="login" -->
            </div>
            <div class="signup-link">
               Not a member? <a href="../login/registration.php">Register now</a>
            </div>
         </form>
      </div>
   </body>
</html>
