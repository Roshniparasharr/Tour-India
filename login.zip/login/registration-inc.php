<?php

if (isset($_POST["submit"])){
    
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $age = $_POST["age"];
    $number = $_POST["number"];
    $gender = $_POST["gender"];
    $address = $_POST["address"];
    $email = $_POST["email"];
    $username = $_POST["uid"];
    $pwd = $_POST["pwd"];
    $aadhar = $_POST["aadhar"];

    require_once 'dbh-inc.php';
    require_once 'functions-inc.php';

    if(emptyInputSignup($fname, $lname, $age, $number, $gender, $address, $email, $username, $pwd, $aadhar) !== false){
        header("location: ../mainLogin/animlogin.php?error=emptyinput");
        exit();
    }

    if(invalidUid($username)){
        header("location: ../mainLogin/animlogin.php?error=invaliduid");
        exit();
    }

    if(invalidEmail($email)){
        header("location: ../mainLogin/animlogin.php?error=invlaidemail");
        exit();
    }


    if(uidExists($conn, $username, $email)){
        header("location: ../mainLogin/animlogin.php?error=usernametaken");
        exit();
    }

    createUser($conn,$fname, $lname, $age, $number, $gender, $address, $email, $username, $pwd, $aadhar);

}
else{
    header("location: ../mainLogin/animlogin.php");
    exit();
}